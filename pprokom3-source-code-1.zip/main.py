feeling = input('How are you?')
if feeling.lower() == 'great':
    print('I feel great too.')
else :
    print('I hope the rest of your day is good.')
    
    