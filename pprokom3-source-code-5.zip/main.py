blog = 'Klinik' + 'Pyhton'
print(blog) 
newblog = blog*5
print(newblog)
blog *= 4
print(blog)
string = 'Klinik' 'Phyton'
print(string)
buah = 'Nanas'
print(buah)
print(buah[0])
print(buah[0:2])
print(buah[0:4])
print(buah[0:5])

