m = ['Alice','ants','Bob','Carol','cats']
m.sort()
print(m)
spam = ['a','z','A','Z']
spam.sort(key=str.lower)
print(spam)
