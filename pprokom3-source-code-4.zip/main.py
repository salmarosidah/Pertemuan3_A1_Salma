str = "Py'thon"
print(str)
str2 = 'Py"thon'
print(str2)
"\OK, \" sampai ketemu lagi."
teks = " Phyton adalah bahasa pemrograman yang powerfull.\n Terbukti Phyton bisa dijalankan di segala platform OS.\n Jadi, saatnya kita menggunakan Phyton sebagai bahasa pemrograman \n sehari-hari.\n Salam Phyton Dahsyat!"
print(teks)
kata = """... Phyton adalah bahasa pemrograman yang powerfull.
... Terbukti Phyton bisa dijalankan di segala platform OS.
... Jadi, saatnya kita menggunakan Phyton sebagai bahasa pemrograman
... sehari-hari. Salam Phyton Dahsyat!"""
print(kata) 